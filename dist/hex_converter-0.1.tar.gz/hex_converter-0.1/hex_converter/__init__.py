# src/__init__.py

# This file is used to initialize package-level variables
